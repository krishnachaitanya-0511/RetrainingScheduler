# RetrainingScheduler
This is tool written in C#.NET, Console based tool, but can be ported to any other type of application as modules are broken properly
