﻿using System;
using System.Globalization;

namespace RetrainingScheduler.DAL.Models {
    /// <summary>
    /// Represents a day of Presentation
    /// </summary>
    public class Track {
        public MorningFixture Morning { get; set; }
        public Session Lunch { get; set; }
        public Session Sharing { get; set; }
        public EveningFixture Evening { get; set; }

        /// <summary>
        /// Add Lunch if there are sessions later
        /// </summary>
        public void AddLunch() {
            Lunch = new Session("Lunch", 60);
            Lunch.Start = "12:00 PM";
        }

        /// <summary>
        /// Add Sharing Session if there are sessions for next day
        /// </summary>
        public void AddSharing() {
            Sharing = new Session("Sharing Session", 0);
            var dt = DateTime.ParseExact("9/8/2019 4:00:00 PM", "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);
            var duration =
            (DateTime.ParseExact("9/8/2019 5:30:00 PM", "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture) -
             Evening.Time).TotalMinutes;
            Sharing.Start = Evening.Time >= dt
                ? Evening.Time.ToString("hh:mm tt", CultureInfo.InvariantCulture)
                : "05:00 PM";
            Sharing.Duration = (int) duration;
        }
    }
}
