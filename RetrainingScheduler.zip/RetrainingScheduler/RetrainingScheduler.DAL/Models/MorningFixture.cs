﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace RetrainingScheduler.DAL.Models {
    /// <inheritdoc />
    /// <summary>
    /// Morning fixture of a day which should start from 09:00 AM and end before 12:00 PM as Lunch starts
    /// </summary>
    public class MorningFixture : DayFixture {
        public DateTime Time =
            DateTime.ParseExact("9/8/2019 9:00:00 AM", "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);

        public MorningFixture() {
            durationLeft = (int) DayFixtureDuration.Morning;
            Sessions = new List<Session>();
        }

        /// <summary>
        /// add the session into the fixture if fits
        /// </summary>
        /// <param name="session">User session</param>
        /// <returns></returns>
        public bool FitMe(Session session) {
            if (session.Duration > durationLeft) return false;
            session.Start = Time.ToString("hh:mm tt", CultureInfo.InvariantCulture);
            Time = Time.AddMinutes(session.Duration);
            durationLeft -= session.Duration;
            Sessions.Add(session);
            return true;
        }        
    }
}
