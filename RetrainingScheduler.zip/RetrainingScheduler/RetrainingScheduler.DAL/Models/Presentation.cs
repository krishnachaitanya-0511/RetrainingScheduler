﻿using System.Collections.Generic;

namespace RetrainingScheduler.DAL.Models {
    /// <summary>
    /// Full presentation across multiple days
    /// </summary>
    public class Presentation {
        public string Message { get; set; }

        public bool Status { get; set; }

        public List<Track> Tracks { get; set; }

        public Presentation() {
            Tracks= new List<Track>();
        }
    }
}
