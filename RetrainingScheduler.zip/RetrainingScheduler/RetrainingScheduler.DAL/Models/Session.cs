﻿namespace RetrainingScheduler.DAL.Models {
    /// <summary>
    /// Single session
    /// </summary>
    public class Session {
        public int Duration { get; set; }
        public string Name { get; set; }

        public string Start { get; set; }

        public Session(string name, int duration) {
            Name = name;
            Duration = duration;
        }       
    }
}
