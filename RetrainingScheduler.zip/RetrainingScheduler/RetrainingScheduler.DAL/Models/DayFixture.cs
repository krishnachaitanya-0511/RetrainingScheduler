﻿using System.Collections.Generic;

namespace RetrainingScheduler.DAL.Models {
    /// <summary>
    /// Base class for either morning or evening fixture
    /// </summary>
    public class DayFixture {
        protected int durationLeft;
        public List<Session> Sessions { get; set; }
    }
}
