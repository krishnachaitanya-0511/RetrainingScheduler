﻿namespace RetrainingScheduler.DAL {
    /// <summary>
    /// Morning and Evening session fixed durations as per the case study
    /// </summary>
    public enum DayFixtureDuration {
        Morning = 180,
        Evening = 240
    }
}
