﻿using System;
using System.Collections.Generic;
using RetrainingScheduler.Services;
using RetrainingScheduler.Services.Models;

namespace RetrainingScheduler {
    internal class Program {
        /// <summary>
        /// Frontend User Interface
        /// </summary>
        private static void Main() {
            var sessions = new List<Session>();
            var presentation = new PresentationService();

            Console.Write("Hey, do you wish to enter sessions on your own? hit y (or) n, else a sample set of sessions shall run?: ");
            var addSession = Console.ReadKey().KeyChar;

            if (addSession.Equals('n')) {
                sessions.Add(new Session("Organising Parents for Academy Improvements", 60));
                sessions.Add(new Session("Teaching Innovations in the Pipeline", 45));
                sessions.Add(new Session("Teacher Computer Hacks", 30));
                sessions.Add(new Session("Making Your Academy Beautiful", 45));
                sessions.Add(new Session("Academy Tech Field Repair", 45));
                sessions.Add(new Session("Sync Hard", 5));
                sessions.Add(new Session("Unusual Recruiting", 5));
                sessions.Add(new Session("Managing Your Dire Allowance", 45));
                sessions.Add(new Session("Customer Care", 30));
                sessions.Add(new Session("AIMs – 'Managing Up'", 30));
                sessions.Add(new Session("Dealing with Problem Teachers", 190));
                sessions.Add(new Session("Hiring the Right Cook", 60));
                sessions.Add(new Session("Government Policy Changes and Bridge", 60));
                sessions.Add(new Session("Adjusting to Relocation", 45));
                sessions.Add(new Session("Public Works in Your Community", 30));
                sessions.Add(new Session("Talking To Parents About Billing", 30));
                sessions.Add(new Session("So They Say You're a Devil Worshipper", 60));
                sessions.Add(new Session("Two - Streams or Not Two - Streams", 60));
                sessions.Add(new Session("Piped Water", 30));
            } else {
                Console.Clear();
                while (addSession.Equals('y')) {
                    Console.WriteLine("Please add a session");
                    Console.WriteLine();
                    Console.Write("Session name: ");
                    var name = Console.ReadLine();
                    Console.Write("Duration in minutes, please numeric values only: ");
                    var duration = Console.ReadLine();
                    if (duration != null && duration.ToLower().Equals("lightning"))
                        duration = "5";                    
                    int number;
                    var isNumeric = int.TryParse(duration, out number);
                    while (!isNumeric) {
                        Console.Write("Invaid minutes, please numeric values only: ");
                        duration = Console.ReadLine();
                        if (duration != null && duration.ToLower().Equals("lightning"))
                            duration = "5";
                        isNumeric = int.TryParse(duration, out number);
                    }                   
                    sessions.Add(new Session(name, number));

                    Console.Write("Do you wish to add another session? y (or) n: ");
                    addSession = Console.ReadKey().KeyChar;
                    Console.Clear();
                }
            }            
            Console.Clear();
            Console.WriteLine(presentation.PrepareSchedule(sessions));
            Console.ReadLine();
        }
    }
}
