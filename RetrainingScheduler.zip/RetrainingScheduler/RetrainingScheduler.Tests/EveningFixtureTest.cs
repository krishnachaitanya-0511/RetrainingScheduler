﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RetrainingScheduler.Services.Models;
using SessionDAL = RetrainingScheduler.DAL.Models.Session;

namespace RetrainingScheduler.Tests {
    [TestClass]
    public class EveningFixtureTest {
        [TestMethod]
        public void FitMe_GreaterDuration_Fail() {
            // Arrange
            var fixture = new MorningFixture();

            // Act
            var actual = fixture.FitMe(new SessionDAL("Sample", 250));

            // Assert
            Assert.AreEqual(false, actual);
        }

        [TestMethod]
        public void FitMe_NormalDuration_Success() {
            // Arrange
            var fixture = new MorningFixture();

            // Act
            var actual = fixture.FitMe(new SessionDAL("Sample", 180));

            // Assert
            Assert.AreEqual(true, actual);
        }
    }
}
