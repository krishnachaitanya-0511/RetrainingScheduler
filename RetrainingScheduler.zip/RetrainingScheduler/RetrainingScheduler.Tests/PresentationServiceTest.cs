﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RetrainingScheduler.Services;
using RetrainingScheduler.Services.Models;

namespace RetrainingScheduler.Tests {
    [TestClass]
    public class PresentationServiceTest {
        [TestMethod]
        public void PrepareSchedule_WithFalseStatus_ZeroSessions() {
            // Arrange
            var presentation = new PresentationService();
            var sessionsList = new List<Session>();

            // Act
            presentation.PrepareSchedule(sessionsList);
            // Assert
            Assert.AreEqual(false, presentation.Status);
        }

        [TestMethod]
        public void PrepareSchedule_WithTrueStatus() {
            // Arrange
            var presentation = new PresentationService();
            var sessionsList = new List<Session> {
                                                     new Session("Sample", 10)
                                                 };
            // Act
            presentation.PrepareSchedule(sessionsList);
            // Assert
            Assert.AreEqual(true, presentation.Status);
        }

    }
}
