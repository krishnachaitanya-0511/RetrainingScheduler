﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RetrainingScheduler.Services.Models;
using SessionDAL = RetrainingScheduler.DAL.Models.Session;

namespace RetrainingScheduler.Tests {
    [TestClass]
    public class SessionTest {
        [TestMethod]
        public void ConvertTo_FromServiceSession() {
            // Arrange
            var session = new Session("Sample", 250);
            var sessionDal = new SessionDAL("Sample", 250);
            // Act
            var actual = session.ConvertTo(session);

            // Assert
            Assert.AreEqual(sessionDal.Duration, actual.Duration);
        }        

    }
}
