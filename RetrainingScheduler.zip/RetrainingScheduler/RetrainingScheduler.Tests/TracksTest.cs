﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RetrainingScheduler.Services.Models;

namespace RetrainingScheduler.Tests {
    [TestClass]
    public class TracksTest {
        [TestMethod]
        public void AddLunch() {
            // Arrange
            var track = new Track();

            // Act
            var actual = track.AddLunch();

            // Assert
            Assert.AreEqual(true, actual);
        }

        [TestMethod]
        public void AddSharing_Fail() {
            var track = new Track();

            // Act
            var actual = track.AddSharing();

            // Assert
            Assert.AreEqual(false, actual);
        }
    }
}
