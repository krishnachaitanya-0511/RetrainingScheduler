﻿using System;
using System.Globalization;
using SessionDAL = RetrainingScheduler.DAL.Models.Session;

namespace RetrainingScheduler.Services.Models {
    /// <summary>
    /// Represents a day of Presentation
    /// </summary>
    public class Track {
        public MorningFixture Morning { get; set; }
        public SessionDAL Lunch { get; set; }
        public SessionDAL Sharing { get; set; }
        public EveningFixture Evening { get; set; }

        /// <summary>
        /// Add Lunch if there are sessions later
        /// </summary>
        public bool AddLunch() {
            try {
                Lunch = new SessionDAL("Lunch", 60);
                Lunch.Start = "12:00 PM";
            } catch (Exception) {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Add Sharing Session if there are sessions for next day
        /// </summary>
        public bool AddSharing() {
            try {
                Sharing = new SessionDAL("Sharing Session", 0);
                var dt = DateTime.ParseExact("9/8/2019 4:00:00 PM", "M/d/yyyy h:mm:ss tt",
                    CultureInfo.InvariantCulture);
                var duration =
                (DateTime.ParseExact("9/8/2019 5:30:00 PM", "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture) -
                 Evening.Time).TotalMinutes;
                Sharing.Start = Evening.Time >= dt
                    ? Evening.Time.ToString("hh:mm tt", CultureInfo.InvariantCulture)
                    : "05:00 PM";
                Sharing.Duration = (int) duration;
            } catch (Exception) {
                return false;
            }
            return true;
        }
    }
}
