﻿using System.Collections.Generic;
using SessionDAL = RetrainingScheduler.DAL.Models.Session;

namespace RetrainingScheduler.Services.Models {
    /// <summary>
    /// Base class for either morning or evening fixture
    /// </summary>
    public class DayFixture {
        protected int durationLeft;
        public List<SessionDAL> Sessions { get; set; }
    }
}
