﻿using System.Collections.Generic;

namespace RetrainingScheduler.Services.Models {
    /// <summary>
    /// Full presentation across multiple days
    /// </summary>
    public class Presentation {
        public string Message { get; set; }


        public List<Track> Tracks { get; set; }

        public Presentation() {
            Tracks = new List<Track>();
        }
    }
}
