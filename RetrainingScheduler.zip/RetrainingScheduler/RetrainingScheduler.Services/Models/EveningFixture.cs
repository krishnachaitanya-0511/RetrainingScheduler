﻿using System;
using System.Collections.Generic;
using System.Globalization;
using RetrainingScheduler.DAL;
using SessionDAL = RetrainingScheduler.DAL.Models.Session;

namespace RetrainingScheduler.Services.Models {
    /// <inheritdoc />
    /// <summary>
    /// Evening fixture of a day which should start from 01:00 PM and end before 05:00 PM as Sharing Session starts
    /// </summary>
    public class EveningFixture : DayFixture {
        public DateTime Time =
            DateTime.ParseExact("9/8/2019 1:00:00 PM", "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);

        public EveningFixture() {
            durationLeft = (int) DayFixtureDuration.Evening;
            Sessions = new List<SessionDAL>();
        }

        /// <summary>
        /// add the session into the fixture if fits
        /// </summary>
        /// <param name="session">User session</param>
        /// <returns></returns>
        public bool FitMe(SessionDAL session) {
            if (session.Duration > durationLeft) return false;
            session.Start = Time.ToString("hh:mm tt", CultureInfo.InvariantCulture);
            Time = Time.AddMinutes(session.Duration);
            durationLeft -= session.Duration;
            Sessions.Add(session);
            return true;
        }
    }
}