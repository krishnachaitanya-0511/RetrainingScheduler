﻿using System;
using System.Collections.Generic;
using System.Text;
using RetrainingScheduler.Services.Models;

namespace RetrainingScheduler.Services {
    /// <summary>
    /// Service layer for full presentation related activities
    /// </summary>
    public class PresentationService {
        private readonly Presentation presentation;

        public bool Status;

        public PresentationService() {
            presentation = new Presentation();
        }

        /// <summary>
        /// Creates multi day presentation
        /// </summary>
        /// <param name="sessions">User provided sessions</param>
        /// <returns></returns>
        public string PrepareSchedule(List<Session> sessions) {
            try {
                if (sessions.Count <= 0) {
                    presentation.Message = "Invalid data";
                    return ShowPresentation();
                }
                CreateExtraSessions(ref sessions);
                presentation.Tracks = new List<Track>();
                while (sessions.Count > 0) {
                    var track = new Track();
                    track.Morning = new MorningFixture();
                    for (var i = 0; i < sessions.Count; i++) {
                        var session = sessions[i].ConvertTo(sessions[i]);
                        if (!track.Morning.FitMe(session)) continue;
                        sessions.Remove(sessions[i]);
                        i--;
                    }
                    if (sessions.Count <= 0) {
                        presentation.Tracks.Add(track);
                        continue;
                    }
                    track.AddLunch();
                    track.Evening = new EveningFixture();
                    for (var i = 0; i < sessions.Count; i++) {
                        var session = sessions[i].ConvertTo(sessions[i]);
                        if (!track.Evening.FitMe(session)) continue;
                        sessions.Remove(sessions[i]);
                        i--;
                    }
                    track.AddSharing();
                    if (sessions.Count <= 0) {
                        presentation.Tracks.Add(track);
                        continue;
                    }
                    presentation.Tracks.Add(track);
                }
                Status = true;
                presentation.Message = "Successfuly created presentation.";
            } catch (Exception ex) {
                presentation.Message = ex.Message;
            }
            return ShowPresentation();
        }

        /// <summary>
        /// Creates broken down sessions if a session doesn't fit a fixture or day
        /// </summary>
        /// <param name="sessions">User provided sessions</param>
        private static void CreateExtraSessions(ref List<Session> sessions) {
            for (var i = 0; i < sessions.Count; i++) {
                if (sessions[i].Duration <= 180) continue;
                sessions.Insert(i, new Session(sessions[i].Name, 180));
                sessions[i + 1].Duration -= 180;
            }
        }

        /// <summary>
        /// Returns renderable string for presentation, this can have other flavours returning JSON etc depending on the type of tool...
        /// </summary>
        /// <returns></returns>
        private string ShowPresentation() {
            var result = new StringBuilder();
            try {
                if (Status) {
                    result.AppendLine("Retraining presentation");
                    result.AppendLine();
                    foreach (var track in presentation.Tracks) {
                        if (track.Morning != null)
                            foreach (var session in track.Morning.Sessions) {
                                result.AppendLine($"{session.Name}:  {session.Start}");
                            }
                        if (track.Lunch != null)
                            result.AppendLine($"{track.Lunch.Name}:  {track.Lunch.Start}");
                        if (track.Evening != null)
                            foreach (var session in track.Evening.Sessions) {
                                result.AppendLine($"{session.Name}:  {session.Start}");
                            }
                        if (track.Sharing != null)
                            result.AppendLine($"{track.Sharing.Name}:  {track.Sharing.Start}");

                    }
                } else {
                    result.AppendLine(presentation.Message);
                }
            } catch (Exception ex) {
                return $"Error occured during rendering of presentation: {ex.Message}";
            }
            return result.ToString();
        }
    }
}
